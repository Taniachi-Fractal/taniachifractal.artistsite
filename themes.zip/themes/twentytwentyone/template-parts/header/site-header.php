<?php
/**
 * Displays the site header.
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_One
 * @since Twenty Twenty-One 1.0
 */

$wrapper_classes  = 'site-header';
$wrapper_classes .= has_custom_logo() ? ' has-logo' : '';
$wrapper_classes .= ( true === get_theme_mod( 'display_title_and_tagline', true ) ) ? ' has-title-and-tagline' : '';
$wrapper_classes .= has_nav_menu( 'primary' ) ? ' has-menu' : '';
?>

<style>
   li {
    list-style-type: none; /* Убираем маркеры у списка */
   }
  </style>

<header id="masthead" class="<?php echo esc_attr( $wrapper_classes ); ?>">
<ul>
	
	<li><a href="http://mysite5.rus/landing-page"><img src="http://mysite5.rus/wp-content/uploads/2023/03/logo.png" alt="Мой автопортрет" width=60 class="logo"></a>
		<h4><b>Taniachi Fractal</b></h4></li>
	<li>   <h5><i>сайт художника</i></h5></li>
	<li><h6>
		Не профессиональный художник, но могу Вам нарисовать векторную картинку или создать 3D модель с анимацией.
		</h6></li>
	<li>ㅤㅤ</li>
	
	<li> <div class="tab">
		<nav>
        <ul>
			<li><a href="http://mysite5.rus/%d0%ba%d0%b0%d1%82%d0%b0%d0%bb%d0%be%d0%b3-2d-%d1%80%d0%b0%d0%b1%d0%be%d1%82-1-%d1%81%d1%82%d1%80%d0%b0%d0%bd%d0%b8%d1%86%d0%b0/">2D</a>
              <ul>
                  <li><a href="http://mysite5.rus/%d0%ba%d0%b0%d1%82%d0%b0%d0%bb%d0%be%d0%b3-2d-%d1%80%d0%b0%d0%b1%d0%be%d1%82-%d0%b1%d0%b5%d0%b7-%d1%84%d0%be%d0%bd%d0%b0/">Без фона</a></li>
                  <li><a href="http://mysite5.rus/%d0%ba%d0%b0%d1%82%d0%b0%d0%bb%d0%be%d0%b3-2d-%d1%80%d0%b0%d0%b1%d0%be%d1%82-%d1%81-%d1%84%d0%be%d0%bd%d0%be%d0%bc/">С фоном</a></li>
			  </ul></li>
        </nav>
			<nav>
        <ul>
			<li><a href="http://mysite5.rus/%d0%ba%d0%b0%d1%82%d0%b0%d0%bb%d0%be%d0%b3-3d-%d1%80%d0%b0%d0%b1%d0%be%d1%82/">3D</a>
              <ul>
                  <li><a href="http://mysite5.rus/%d0%ba%d0%b0%d1%82%d0%b0%d0%bb%d0%be%d0%b3-3d-%d1%80%d0%b0%d0%b1%d0%be%d1%82-%d0%b1%d0%b5%d0%b7-%d0%b0%d0%bd%d0%b8%d0%bc%d0%b0%d1%86%d0%b8%d0%b8/">Без анимации</a></li>
                  <li><a href="http://mysite5.rus/%d0%ba%d0%b0%d1%82%d0%b0%d0%bb%d0%be%d0%b3-3d-%d1%80%d0%b0%d0%b1%d0%be%d1%82-%d1%81-%d0%b0%d0%bd%d0%b8%d0%bc%d0%b0%d1%86%d0%b8%d0%b5%d0%b9/">С анимацией</a></li>
			  </ul></li>
        </nav>
        <button onclick="document.location='http://mysite5.rus/%d0%ba%d1%83%d0%bf%d0%b8%d1%82%d1%8c-%d1%80%d0%b0%d0%b1%d0%be%d1%82%d1%83/'">Обратная связь</button>
        <button onclick="document.location='http://mysite5.rus/cart/'">Корзина</button>
        <button></button>
        <nav>
        <ul>
			<li><a>Соцсети</a>
              <ul>
                  <li><a href="https://vk.com/tanyaslowpokeoil">Мой ВК</a></li>
                  <li><a href="https://sketchfab.com/Taniachi_Fractal">Мой Sketchfab</a></li>
			  </ul></li>
      </nav>
      <div class="close_tab"></div></div></div>
	</li>
</ul>
</ul>
	
</header><!-- #masthead -->
